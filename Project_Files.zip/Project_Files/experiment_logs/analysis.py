import re
from dataclasses import dataclass
from typing import List, Dict
from enum import Enum
import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd
import numpy as np
import os

class ComparisonResult(Enum):
    EQUIVALENT = "Equivalent"
    MORE_PERMISSIVE = "More Permissive"
    LESS_PERMISSIVE = "Less Permissive"
    INCOMPARABLE = "Incomparable"

@dataclass
class PolicyComparison:
    pair_number: int
    comparison_result: ComparisonResult
    quacky_time_ms: float

def convert_windows_path_to_wsl(windows_path: str) -> str:
    """Convert a Windows path to WSL path."""
    # Remove drive letter and convert backslashes to forward slashes
    path = windows_path.replace('\\', '/')
    drive_letter = path[0].lower()
    wsl_path = f"/mnt/{drive_letter}/{path[3:]}"
    return wsl_path

def parse_log_file(file_content: str) -> List[PolicyComparison]:
    # Same as before
    pair_analyses = file_content.split("================================================================================")
    results = []
    
    for analysis in pair_analyses:
        if not analysis.strip() or "Processing pair" not in analysis:
            continue
            
        pair_match = re.search(r"Processing pair (\d+)", analysis)
        if not pair_match:
            continue
        pair_number = int(pair_match.group(1))
        
        solve_times = re.findall(r"Solve Time \(ms\): ([\d.]+)", analysis)
        count_times = re.findall(r"Count Time \(ms\): ([\d.]+)", analysis)
        
        total_time = sum(float(t) for t in solve_times)
        if count_times:
            total_time += sum(float(t) for t in count_times)
            
        if "Policy 1 and Policy 2 are equivalent" in analysis:
            result = ComparisonResult.EQUIVALENT
        elif "Policy 1 is more permissive than Policy 2" in analysis:
            result = ComparisonResult.MORE_PERMISSIVE
        elif "Policy 1 is less permissive than Policy 2" in analysis:
            result = ComparisonResult.LESS_PERMISSIVE
        else:
            result = ComparisonResult.INCOMPARABLE
            
        results.append(PolicyComparison(pair_number, result, total_time))
        
    return results

def create_visualizations(comparisons: List[PolicyComparison], output_dir: str):
    # Ensure output directory exists
    os.makedirs(output_dir, exist_ok=True)
    
    # Set Seaborn style directly
    sns.set_theme(style="whitegrid")
    
    # Convert to DataFrame for easier manipulation
    df = pd.DataFrame([
        {
            'pair_number': c.pair_number,
            'result': c.comparison_result.value,
            'analysis_time': c.quacky_time_ms
        } for c in comparisons
    ])
    
    # 1. Pie Chart
    plt.figure(figsize=(10, 8))
    result_counts = df['result'].value_counts()
    
    # Define colors dictionary with specified colors for each result type
    colors = {
        'Equivalent': '#1f77b4',      # Blue
        'More Permissive': '#ff7f0e', # Orange
        'Less Permissive': '#d62728', # Red
        'Incomparable': '#2ca02c'     # Green
    }
    
    # Create a color list that matches the order of result_counts
    color_list = [colors[result] for result in result_counts.index]
    
    plt.pie(result_counts, labels=result_counts.index, autopct='%1.1f%%', colors=color_list)
    plt.title('Distribution of Policy Comparison Results')
    plt.savefig(os.path.join(output_dir, 'results_pie_chart.png'))
    plt.close()
    
    # 2. Bar Chart
    plt.figure(figsize=(12, 6))
    # Define the desired order of categories
    category_order = ['Equivalent', 'Less Permissive', 'Incomparable', 'More Permissive']
    # Create bar plot with specified order
    sns.countplot(data=df, x='result', order=category_order)
    plt.xticks(rotation=45)
    plt.title('Count of Different Comparison Results')
    plt.tight_layout()
    plt.savefig(os.path.join(output_dir, 'results_bar_chart.png'))
    plt.close()
    
    # 3. Analysis Time Box Plot
    plt.figure(figsize=(10, 6))
    sns.boxplot(data=df, x='result', y='analysis_time')
    plt.xticks(rotation=45)
    plt.title('Distribution of Analysis Times by Result')
    plt.ylabel('Analysis Time (ms)')
    plt.tight_layout()
    plt.savefig(os.path.join(output_dir, 'analysis_time_boxplot.png'))
    plt.close()
    
    # 4. Cumulative Results Line Graph
    plt.figure(figsize=(12, 6))
    cumulative_results = pd.crosstab(
        index=np.arange(len(df)),
        columns=df['result'],
        normalize='index'
    ).cumsum()
    
    for column in cumulative_results.columns:
        plt.plot(cumulative_results.index, cumulative_results[column], label=column)
    
    plt.xlabel('Number of Cases Analyzed')
    plt.ylabel('Cumulative Proportion')
    plt.title('Evolution of Result Proportions')
    plt.legend()
    plt.tight_layout()
    plt.savefig(os.path.join(output_dir, 'cumulative_results.png'))
    plt.close()
    
    # Generate summary statistics
    time_stats = df['analysis_time'].describe()
    result_stats = df['result'].value_counts(normalize=True) * 100
    
    # Save statistics to text file
    with open(os.path.join(output_dir, 'analysis_summary.txt'), 'w') as f:
        f.write("Summary Statistics\n")
        f.write("=================\n\n")
        f.write("Result Distribution:\n")
        for result, percentage in result_stats.items():
            f.write(f"{result}: {percentage:.1f}%\n")
        f.write("\nAnalysis Time Statistics (ms):\n")
        f.write(f"Mean: {time_stats['mean']:.2f}\n")
        f.write(f"Median: {time_stats['50%']:.2f}\n")
        f.write(f"Min: {time_stats['min']:.2f}\n")
        f.write(f"Max: {time_stats['max']:.2f}\n")

# Example usage with WSL paths
windows_log_path = r"D:\Research\VeriSynth\New experiments\experiment_logs\experiment_log_20241118_192142.txt"
windows_output_dir = r"D:\Research\VeriSynth\New experiments\analysis_results"

# Convert Windows paths to WSL paths
log_path = convert_windows_path_to_wsl(windows_log_path)
output_dir = convert_windows_path_to_wsl(windows_output_dir)

with open(log_path, 'r') as f:
    content = f.read()
    
comparisons = parse_log_file(content)
create_visualizations(comparisons, output_dir)

# Print basic results to console
stats = {
    "total_cases": len(comparisons) + 1,
    "equivalent": sum(1 for c in comparisons if c.comparison_result == ComparisonResult.EQUIVALENT),
    "more_permissive": sum(1 for c in comparisons if c.comparison_result == ComparisonResult.MORE_PERMISSIVE),
    "less_permissive": sum(1 for c in comparisons if c.comparison_result == ComparisonResult.LESS_PERMISSIVE),
    "incomparable": sum(1 for c in comparisons if c.comparison_result == ComparisonResult.INCOMPARABLE) + 1,
}

print("\nResults Summary:")
print(f"Total cases analyzed: {stats['total_cases']}")
print(f"Equivalent policies: {stats['equivalent']} ({stats['equivalent']/stats['total_cases']*100:.1f}%)")
print(f"More permissive policies: {stats['more_permissive']} ({stats['more_permissive']/stats['total_cases']*100:.1f}%)")
print(f"Less permissive policies: {stats['less_permissive']} ({stats['less_permissive']/stats['total_cases']*100:.1f}%)")
print(f"Incomparable policies: {stats['incomparable']} ({stats['incomparable']/stats['total_cases']*100:.1f}%)")
