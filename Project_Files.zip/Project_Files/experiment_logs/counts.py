def analyze_policy_comparisons(log_content):
    # Initialize variables to track differences and count
    total_diff = 0
    count = 0
    
    # Split the log into pairs
    pairs = log_content.split("Processing pair")
    
    for pair_index, pair in enumerate(pairs, 1):  # Start enumeration from 1 for readable case numbering
        # Skip if not a Quacky Results section
        if "Quacky Results:" not in pair:
            continue
            
        # Check if this is a case where one policy is more/less permissive
        if "is more permissive than" in pair or "is less permissive than" in pair:
            # Find all lg(requests) values in this pair
            lg_requests = []
            for line in pair.split('\n'):
                if "lg(requests):" in line:
                    value = float(line.split("lg(requests):")[1].strip())
                    lg_requests.append(value)
            
            # Process and print the values for this case
            if len(lg_requests) == 2:
                diff = abs(lg_requests[0] - lg_requests[1])
                print(f"Case {pair_index}: lg(requests) values: {lg_requests[0]:.2f}, {lg_requests[1]:.2f} (diff: {diff:.2f})")
                total_diff += diff
                count += 1
            elif len(lg_requests) == 1:
                # Handle cases with one value (other is implicitly 0)
                diff = abs(lg_requests[0] - 0)
                print(f"Case {pair_index}: lg(requests) values: {lg_requests[0]:.2f}, 0.00 (diff: {diff:.2f})")
                total_diff += diff
                count += 1
    
    # Calculate and return the average
    if count > 0:
        avg_diff = total_diff / count
        return avg_diff, count
    else:
        return 0, 0

# WSL path format
file_path = "/mnt/d/Research/VeriSynth/New experiments/experiment_logs/experiment_log_20241118_192142.txt"

try:
    with open(file_path, 'r') as file:
        log_content = file.read()
        avg_diff, num_cases = analyze_policy_comparisons(log_content)
        print(f"Average absolute difference in log(requests): {avg_diff:.2f}")
        print(f"Number of cases analyzed: {num_cases}")
except FileNotFoundError:
    print(f"Error: Could not find file at {file_path}")
except Exception as e:
    print(f"Error: {str(e)}")
